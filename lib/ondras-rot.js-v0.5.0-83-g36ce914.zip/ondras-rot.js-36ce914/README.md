rot.js
======

ROguelike Toolkit

More info: http://ondras.github.com/rot.js

RogueBasin page (with links to some rot.js-based games): http://www.roguebasin.roguelikedevelopment.org/index.php?title=Rot.js
