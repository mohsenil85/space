/**
 * Export to Node.js module
 */
for (var p in ROT) {
	exports[p] = ROT[p];
}
